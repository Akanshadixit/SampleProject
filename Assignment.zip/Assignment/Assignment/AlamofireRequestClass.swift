//
//  AlamofireRequest.swift
//  Assignment
//
//  Created by Akansha Dixit on 25/04/20.
//  Copyright © 2020 Akansha Dixit. All rights reserved.
//

import Foundation
import Alamofire

class AlamofireRequestClass {
    
    typealias completionHandler = (NSDictionary) -> Void
  
    // MARK: API Calling method
    class func fetchingData(completionHandler: @escaping completionHandler) {        AF.request("https://www.alphavantage.co/query?function=SECTOR&apikey=FHXWA7EBLCYFTDLW").response {
            response in
            debugPrint(response)
        do {
     let serviceData =   try JSONSerialization.jsonObject(with: response.data!, options: []) as? [String: Any]
            completionHandler(serviceData! as NSDictionary)
        }
         catch {
            print("JSONSerialization error:", error)
        }

        }
    }
}
