//
//  AssigmentTableViewCell.swift
//  Assignment
//
//  Created by Akansha Dixit on 26/04/20.
//  Copyright © 2020 Akansha Dixit. All rights reserved.
//

import Foundation
import UIKit

class AssigmentTableViewCell : UITableViewCell {
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var ratioLabel: UILabel!
}
