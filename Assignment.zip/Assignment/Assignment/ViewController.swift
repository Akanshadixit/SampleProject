//
//  ViewController.swift
//  Assignment
//
//  Created by Akansha Dixit on 25/04/20.
//  Copyright © 2020 Akansha Dixit. All rights reserved.
//

import UIKit
import Alamofire

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    var dictData:NSDictionary = [:]
    var rankA:NSDictionary = [:]
     var rankB:NSDictionary = [:]
     var rankC:NSDictionary = [:]
     var rankE:NSDictionary = [:]
    var sliderValue:Float = 0.0
    var keyArray:Array<Any> = []
    var valueArray:Array<Any> = []

    @IBOutlet weak var settingButton: UIButton!
    @IBOutlet weak var slider: UISlider!
    @IBOutlet weak var assignmentTableView: UITableView!
    
    @IBAction func sliderSelection(_ sender: Any) {
         sliderValue = self.slider.value
        if(sliderValue .isEqual(to: 1.0) || (sliderValue .isEqual(to: 2.0015244)) || (sliderValue .isEqual(to: 2.7012196)) || (sliderValue .isEqual(to:  3.4466465))){
         self.assignmentTableView.reloadData()
    }
   }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.assignmentTableView.delegate = self
        self.assignmentTableView.dataSource = self
        
        let theme = UserDefaults.standard.string(forKey: "Theme")
        if(theme == "Dark"){
            overrideUserInterfaceStyle = .dark

        }else if(theme == "Light"){
            overrideUserInterfaceStyle = .light
        }
        self.getAssignmentServiceImplemented()
    }
    
    // MARK: API Handling method
    func getAssignmentServiceImplemented(){
    AlamofireRequestClass.fetchingData(completionHandler: { (serviceResponseDic) in
        DispatchQueue.main.async {
            do {
                self.dictData = serviceResponseDic
                
                self.rankA = serviceResponseDic.value(forKey: "Rank A: Real-Time Performance") as! NSDictionary
                self.rankB = serviceResponseDic.value(forKey: "Rank B: 1 Day Performance") as! NSDictionary
                self.rankE = serviceResponseDic.value(forKey: "Rank E: 3 Month Performance") as! NSDictionary
                self.rankC = serviceResponseDic.value(forKey: "Rank C: 5 Day Performance") as! NSDictionary
                /*
                let rankJ = serviceResponseDic.value(forKey: " Rank J: 10 Year Performance")
                let rankH = serviceResponseDic.value(forKey: "Rank H: 3 Year Performance")
                let rankG = serviceResponseDic.value(forKey: "Rank G: 1 Year Performance")
                let rankI = serviceResponseDic.value(forKey: "Rank I: 5 Year Performance")
                let rankF = serviceResponseDic.value(forKey: "Rank F: Year-to-Date (YTD) Performance")
                */
                
                    DispatchQueue.main.async {
                        self.assignmentTableView.reloadData()
                    }
            }
            catch {
                print("Login: Error creating jsonObj from jsonData")
            }
        }
    })
    }
    
    // MARK: button click method
    @IBAction func settingButtonPressed(_ sender: Any)
       {
           let alert = UIAlertController(title: "Title", message: "Please Select theme", preferredStyle: .actionSheet)

           alert.addAction(UIAlertAction(title: "Light Theme", style: .default , handler:{ (UIAlertAction)in
               print("User click Approve button")
               UserDefaults.standard.set("Light", forKey: "Theme")
           }))

           alert.addAction(UIAlertAction(title: "Dark Theme", style: .default , handler:{ (UIAlertAction)in
               print("User click Edit button")
               UserDefaults.standard.set("Dark", forKey: "Theme")
           }))


           alert.addAction(UIAlertAction(title: "Dismiss", style: .cancel, handler:{ (UIAlertAction)in
               print("User click Dismiss button")
           }))

           self.present(alert, animated: true, completion: {
               print("completion block")
           })
       }
       
    
   // MARK: tableview delegate methods
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.dictData.count
     }
     
     func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "assignmentCell", for: indexPath) as! AssigmentTableViewCell
        
        if(sliderValue .isLessThanOrEqualTo(2.0)){
            keyArray = Array(self.rankA.allKeys)
            valueArray = Array(self.rankA.allValues)
        }else
        if((sliderValue .isLessThanOrEqualTo(2.7)) || (sliderValue.isEqual(to: 2.1))){
            keyArray = Array(self.rankB.allKeys)
            valueArray = Array(self.rankB.allValues)
        }else
        if((sliderValue .isLessThanOrEqualTo(2.8)) || (sliderValue.isEqual(to: 3.4))){
            keyArray = Array(self.rankC.allKeys)
            valueArray = Array(self.rankC.allValues)
        }else
        if((sliderValue .isLessThanOrEqualTo(4.0)) || (sliderValue.isEqual(to: 3.4))){
            keyArray = Array(self.rankE.allKeys)
            valueArray = Array(self.rankE.allValues)
            }
        cell.nameLabel.text = keyArray[indexPath.row] as? String
        cell.ratioLabel.text = valueArray[indexPath.row] as? String
       return cell
 
     }
     
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    


}

